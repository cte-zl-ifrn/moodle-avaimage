<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * @author     Saulo Sá <srssaulo@gmail.com>
 * @package    block_plaforedu
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class block_plaforedu extends block_base
{
    /**
     * Initialize the plugin. This method is being called by the parent constructor by default.
     */
    public function init()
    {
        //print_object($this->page->blocks->get_regions());
        //$this->page->blocks->set_default_region("side-pre");

        $this->title = get_string('blocktitle', 'block_plaforedu');
    }

    /**
     * No need to have multiple blocks to perform the same functionality
     */
    public function instance_allow_multiple(): bool
    {
        return false;
    }

    /**
     * Has config function.
     *
     * @see block_base::has_config()
     */
    public function has_config()
    {
        return true;
    }

    private function get_content_html($idc){
        global $DB, $CFG;


        $have_cm = $DB->record_exists('plaforedu_required_cert', ['idc'=>$idc]);


        if($have_cm){
            $label = "Edite os cetificados obrigatórios";
            $alert = 'warning';
            $btnLabel = "Edite";
        }else{
            $label = "O curso ainda não possui cerficados obrigatórios";
            $alert = 'danger';
            $btnLabel = "Configure";
        }


        $lnk = new moodle_url('/blocks/plaforedu/add_required_certificates.php',['idc'=>$idc]);
        $lnk = $lnk->out();

       return <<<HTML
        <div id="block-plaforedu" class="block-plaforedu">
        
        <div class="alert alert-{$alert}" role="alert">{$label}</div>
            
         <a href="{$lnk}" class="btn btn-primary btn-lg active" role="button" aria-pressed="true">{$btnLabel}</a>
        
        </div>



HTML;

    }

    /**
     * Sets up the content of the block for display to the user.
     *
     * @return stdClass The HTML content of the block.
     * @throws coding_exception
     * @throws moodle_exception
     */
    public function get_content(): stdClass
    {
        global $CFG, $COURSE, $OUTPUT;


        if ($this->content !== null) {
            return $this->content;
        }

        $this->content = new stdClass();

        $this->content->text = $this->get_content_html($COURSE->id);

        $this->content->footer = '';

        return $this->content;

    }


}
