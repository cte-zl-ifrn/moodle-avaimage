<?php
require '../../config.php';
require 'classes/Utils.php';
use \block_plaforedu\classes\Utils;

print_object(Utils::get_certificate_available_plugins());
print_object(Utils::get_configs());
print_object(Utils::get_certificates_cm(38));
print_object(Utils::get_certficate_instance_name('certificate', 1));
print_object(Utils::get_permissions(38));


if(!empty(Utils::user_is_aproved(92, 38))){
    echo 'Usuário aprovado';
}else{
    echo 'Usuário não aprovado';
}


print_object(enrol_get_users_courses(92));