<?php
require '../../config.php';
require 'classes/Utils.php';
require 'classes/form/CertificateForm.php';

use \block_plaforedu\classes\Utils;

global $PAGE, $OUTPUT, $DB;


$idc = required_param('idc', PARAM_INT);


Utils::get_permissions($idc);

$url = new moodle_url('/blocks/plaforedu/add_required_certificates.php');
$url->param('idc', $idc);

$PAGE->set_course($DB->get_record('course', array('id' => $idc), '*', MUST_EXIST));
$PAGE->set_url($url);
$PAGE->set_pagelayout('standard');

$PAGE->set_context(context_course::instance($idc));

$PAGE->set_title('Certificados obrigatórios');
$PAGE->set_heading('Certificados obrigatórios para conclusão do curso');

$PAGE->navbar->add(get_string('blocks'));
$PAGE->navbar->add(get_string('pluginname', 'block_plafordu'));
$PAGE->navbar->add('certificados obrigatórios');
echo $OUTPUT->header();
//look block  rss_client/editfeed
echo $OUTPUT->heading('');

$url->param('idc', $idc);

$data['idc'] = $idc;
$data['sbm_lbl'] = 'Enviar';
$isUpdate = Utils::isUpdate($idc);

if($isUpdate){
    $data['sbm_lbl'] = 'Atualizar';
    $data['required_certs']=Utils::get_sl_certificate_values($idc, true);
}

$mform = new CertificateForm($PAGE->url, $data);
$mform->display();

if ($mform->is_cancelled()) {
//redirect( '/my');

} else if ($data = $mform->get_data()) {

    if($isUpdate){
        Utils::deleteForUpdateRecord($idc);
    }
    foreach ($data->required_certs as $cert){
        $obj = new \stdClass();
        $obj->cm = $cert;
        $obj->idc = $idc;
        Utils::store_required_certificate($obj);
    }

    if(count($data->required_certs)>0) {
        echo $OUTPUT->notification('Certificados obrigatórios registrados', 'success');
    }

}


echo $OUTPUT->footer();
