<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * @author     Saulo Sá <srssaulo@gmail.com>
 * @package    block_plaforedu
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['pluginname'] = 'PlaforEdu Define Required Certificate Block' ;
$string['massaction:addinstance'] = 'Add new PlaforEdu block instance';
$string['massaction:use'] = 'Use PlaforEdu Integration blocks';
$string['blockname'] = 'PlaforEdu Integration block';
$string['blocktitle'] = 'PlaforEdu Integration block';
$string['privacy:metadata'] = 'This block only offers the possibility to apply standard operations on multiple course modules at the same time.
Thus, no data is being stored by this block.';

//SETTINGS FIELDS
$string['certificates'] = 'Available certificates check';
$string['certificates_'] = 'Available certificates check. If you select a certificate type, the system will list all
course instance for check if student finished the course';
$string['plaforedu:addrequiredcertificate']='Grant permission to add course conclusion requirements based in selected certificates';

