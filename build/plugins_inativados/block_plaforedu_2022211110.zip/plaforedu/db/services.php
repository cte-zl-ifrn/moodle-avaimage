<?php
/**
 * Repository class.
 *
 * @package    block_plaforedu
 * @copyright  Saulo Sá <srssaulo@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

// We defined the web service functions to install.
$functions = array(
    'block_plaforedu_get_approved_courses' => array(
        'classname'   => 'block_plaforedu_external',
        'methodname'  => 'get_approved_courses',
        'classpath'   => 'blocks/plaforedu/externallib.php',
        'description' => 'Get user\'s approved courses',
        'type'        => 'read',
        'loginrequired' => false,
    ),

);

$services = array(
    'Plaforedu Block service' => array(
        'functions' => array (
            'block_plaforedu_get_approved_courses',
        ),
        'enabled' => 1,
    )
);
