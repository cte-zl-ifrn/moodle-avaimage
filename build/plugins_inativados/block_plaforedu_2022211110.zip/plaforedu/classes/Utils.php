<?php

namespace block_plaforedu\classes;


use core\plugininfo\mod;

class Utils
{

    private const CERTIFICATES = ['certificate', 'customcert'];
    private const PLUGIN_TABLE = 'plaforedu_required_cert';

    /**
     * return plugin configuration values
     * @return array
     * @throws \dml_exception
     */
    public static function get_configs()
    {

        return [
            'certificates' => get_config('block_plaforedu', 'certificates')
        ];

    }


    public static function deleteForUpdateRecord($idc)
    {
        global $DB;
        $DB->delete_records(self::PLUGIN_TABLE, ['idc' => $idc]);

    }

    public static function isUpdate($idc)
    {
        global $DB;
        return $DB->record_exists(self::PLUGIN_TABLE, ['idc' => $idc]);
    }

    public static function store_required_certificate($obj)
    {
        global $DB;

        if ($obj->id) {
            //update
            return $DB->update_record(self::PLUGIN_TABLE, $obj);
        }
        return $DB->insert_record(self::PLUGIN_TABLE, $obj);
    }


    /**
     * required capability to access add page
     * @param $courseid
     * @return void
     * @throws \required_capability_exception
     */
    public static function get_permissions($courseid)
    {
        require_capability(
            'block/plaforedu:addrequiredcertificate',
            \context_course::instance($courseid)
        );
    }


    public static function user_is_aproved($uid, $cid)
    {
        global $DB;

        $table_prefix = $DB->get_prefix(); //is necessary here

        $certificate_list = self::CERTIFICATES;
        $requiredCertCms = $DB->get_records(self::PLUGIN_TABLE, ['idc' => $cid], '', 'cm'); // get requireds certificates
        if (count($requiredCertCms) > 0) {
            foreach ($requiredCertCms as $cm) {

                $certificate_name = $DB->get_record_sql(
                    "select m.name from {course_modules} cm
                 inner join {modules} m on cm.module = m.id
                 where cm.id = ?",
                    [$cm->cm]
                )->name;


                $cert_table_issue = $table_prefix . $certificate_name . '_issues';
                $cert_key_issue = 'ci.' . $certificate_name . 'id';
                $certificate_name = $table_prefix . $certificate_name;
                $cmtable = $table_prefix . 'course_modules';


                $SQL_ISSUE = "select ci.id  from $cmtable as cm
                        inner join $certificate_name as ce on cm.instance = ce.id
                        inner join $cert_table_issue as ci on $cert_key_issue=ce.id
                        where cm.id = ?  and ci.userid = ?";


                if ($DB->record_exists_sql($SQL_ISSUE, [$cm->cm, $uid])) {
                    return true;//if on issue exists, user is aproved;
                }

                return false;

            }
        }

        //return true or false in case of no required certificates registered
       return ;//TODO stakeholder define


    }

    public static function get_sl_certificate_values($courseId, $selected = false)
    {
        global $DB;
        $cms = self::get_certificates_cm($courseId);
        $arr_sl = [];
        foreach ($cms as $cm) {
            $arr_sl[$cm->id] = self::get_certficate_instance_name($cm->name, $cm->instance);
        }

        if ($selected) {
            return array_keys($DB->get_records(self::PLUGIN_TABLE, ['idc' => $courseId], '', 'cm'));
        }

        return $arr_sl;
    }

    /**
     * return the certificate name showed for users
     * @param $moduleName string  a valid certificate module type validated with CERTIFICATES const
     * @param $instanceid int id of main certificate table
     * @return mixed
     * @throws \coding_exception
     * @throws \dml_exception
     */
    public static function get_certficate_instance_name($moduleName, $instanceid)
    {
        global $DB;

        if (!in_array($moduleName, self::CERTIFICATES)) {
            throw new \coding_exception('module certificate doesn\'t registered');
        }

        return $DB->get_record($moduleName, ['id' => $instanceid], 'id, name')->name;
    }


    /**
     * return list of course modules ids and modules names assoc.
     * @param $courseid int
     * @return int[]|string[]
     * @throws \dml_exception
     */
    public static function get_certificates_cm($courseid)
    {
        global $DB;

        $inMod = implode(',', array_map(function ($x) {
            return "'$x'";

        }, self::CERTIFICATES));

        $modIDs = $DB->get_records_sql(
            "select cm.id, cm.instance, m.name from {course_modules} cm
            inner join {modules} m on cm.module = m.id
            where cm.course = $courseid and m.name in($inMod)"
        );

        return ($modIDs);
    }


    /**
     * check and return mod certificate list
     * @return array|int
     */
    public static function get_certificate_available_plugins()
    {
        $return = [];
        foreach (self::CERTIFICATES as $cert) {
            if (mod::get_enabled_plugin($cert)) {
                $return[$cert] = get_string('modulename', $cert);
            }
        }

        if (count($return) == 0) {
            return 0;
        }

        return $return;
    }


}