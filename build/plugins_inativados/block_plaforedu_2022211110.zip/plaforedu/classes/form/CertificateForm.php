<?php
require_once("$CFG->libdir/formslib.php");
//require '../Utils.php';?

use block_plaforedu\classes\Utils;
class CertificateForm extends moodleform
{
    // Add elements to form.
    public function definition() {
        // A reference to the form is stored in $this->form.
        // A common convention is to store it in a variable, such as `$mform`.
        $mform = $this->_form; // Don't forget the underscore!

        $mform->addElement('select', 'required_certs', 'Certificados obrigatórios', Utils::get_sl_certificate_values($this->_customdata['idc']));
        $mform->getElement('required_certs')->setMultiple(true);
        $mform->getElement('required_certs')->setSelected($this->_customdata['required_certs']);
        $this->add_action_buttons(true, $this->_customdata['sbm_lbl']);

        //set data
        $this->set_data($this->_customdata);

    }


    // Custom validation should be added here.
    function validation($data, $files) {
        $errors = parent::validation($data, $files);

        return $errors;
    }

}