# moodle__block_plaforedu

O plugin segue os seguintes requisitos:

- [X] ws que vai retornar os cursos que o CPF já fez (concluiu).
- [X] O CPF que irei consultar é um customfield
- [X] Identificar quais cursos ele concluiu. Se o usuário tem acesso ao certificado.
- [X] Será necessário definir no curso qual(is) o certificado(s) dirá se o usuário concluiu ou não o curso. (mod_certificate, mod_custom_cert). Se o usuário já tiver emitido um dos certificados marcados para o curso, ele é tido como concluído.
- [X] Retorno: fullname,shortname

## Instalação do plugin:

Bloco de integração com o PlaforEDU para Moodle. Clone este projeto como o para o seguinte diretório:
./blocks/plaforedu
