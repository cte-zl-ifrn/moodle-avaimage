<?php

$string['treatfilesasok'] = 'Treat files as OK';
