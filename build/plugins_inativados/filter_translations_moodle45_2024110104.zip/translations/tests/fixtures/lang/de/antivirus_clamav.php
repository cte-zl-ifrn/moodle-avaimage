<?php

$string['treatfilesasok'] = 'Dateien als OK behandeln';
