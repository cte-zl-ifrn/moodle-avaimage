/**
 * The Moodle.mod_offlinequiz.util classes provide offlinequiz-related utility functions.
 *
 * @module moodle-mod_offlinequiz-util
 * @main
 */

Y.namespace('Moodle.mod_offlinequiz.util');