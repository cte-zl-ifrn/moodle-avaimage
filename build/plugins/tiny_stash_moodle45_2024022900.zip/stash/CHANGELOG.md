Tiny Stash
===========

Version 1.0.3 (29th February 2024)
-------------------

* Fixed a bug where students trying to view the TinyMCE editor would crash due to the student not having permission to view items.
* Updating item ajax calls to include a cache.


Version 1.0.2 (25th October 2023)
---------------------------------

* Shortcodes are now being filtered in the editor and show as they will when saved in the activity or course.
* Changed the language in the editor to update "locations" to "drops". This gives an easier idea of what the user is creating within tiny_stash.


Version 1.0.1 (23rd October 2023)
---------------------------------

* Added privacy provider information. This plugin is a null provider as it does not store any user information.


Version 1.0.0 (20th October 2023)
---------------------------------

* Initial release of tiny stash.
