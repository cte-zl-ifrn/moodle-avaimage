define(
    ['jquery', 'core/ajax', 'core/notification', 'core/str', 'core/templates', 'core/url'],
    function($, AJAX, NOTIFICATION, STR, TEMPLATES, URL) {
    return {


    };
});
