# Changelog

All notable changes to this project will be documented in this file.

## [1.0] - 2024-11-05

### First release