<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Block custom_css is defined here.
 *
 * @package     block_course_gallery
 * @copyright   2025 Your Name <you@example.com>
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class block_custom_css extends block_base
{

    /**
     * Initializes class member variables.
     */
    public function init()
    {
        // Needed by Moodle to differentiate between blocks.
        $this->title = get_string('pluginname', 'block_custom_css');
    }

    public function has_config()
    {
        return false;
    }

    public function instance_allow_multiple()
    {
        return false;
    }


    public function instance_allow_config()
    {
        return true;
    }

    /**
     * Returns the block contents.
     *
     * @return stdClass The block contents.
     */
    public function get_content()
    {
        global $USER, $COURSE;

        if ($this->content !== null) {
            return $this->content;
        }

        if (empty($this->instance)) {
            $this->content = '';
            return $this->content;
        }

        $this->content = new stdClass();
        $this->content->footer = '';

        $context = context_course::instance($COURSE->id);
        $isprofessor = has_capability('moodle/course:update', $context);

        $css = isset($this->config->csscode) ? trim($this->config->csscode) : false;

        if (!is_siteadmin()) {
            $css .= '.block_custom_css { display: none !important; }';
        }

        if ($css) {
            $styletag = html_writer::tag('style', $css, ['type' => 'text/css']);
            $info = get_string('info', 'block_custom_css');
            $this->content->text = $styletag . html_writer::tag('div', $info);
        } else {
            $this->content->text = get_string('init_edit', 'block_custom_css');
        }

        return $this->content;
    }


    public function get_required_javascript()
    {
        global $PAGE;

        // Baixado em: https://codemirror.net/codemirror.zip
        $PAGE->requires->css(new moodle_url('/blocks/custom_css/codemirror/codemirror.css'));
        $PAGE->requires->js(new moodle_url('/blocks/custom_css/codemirror/codemirror.js'), true);
        $PAGE->requires->js(new moodle_url('/blocks/custom_css/codemirror/mode/css/css.js'), true);

        $PAGE->requires->js_call_amd('block_custom_css/editor', 'init');
    }


    public function user_can_addto($page)
    {
        return is_siteadmin();
    }

    public function user_can_edit()
    {
        return is_siteadmin();
    }

    /**
     * Sets the applicable formats for the block.
     *
     * @return string[] Array of pages and permissions.
     */
    public function applicable_formats()
    {
        return ['course-view' => true, 'my' => true];
    }
}