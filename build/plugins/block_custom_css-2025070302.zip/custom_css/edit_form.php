<?php

defined('MOODLE_INTERNAL') || die();

// require_once($CFG->dirroot . '/blocks/edit_form.php');

class block_custom_css_edit_form extends block_edit_form {

    protected function specific_definition($mform) {
        $mform->addElement('textarea', 'config_csscode', get_string('pluginname', 'block_custom_css'), 'rows="15" cols="60"');
        $mform->setType('config_csscode', PARAM_RAW);
        $mform->addHelpButton('config_csscode', 'customcss', 'block_custom_css');
    }
}
