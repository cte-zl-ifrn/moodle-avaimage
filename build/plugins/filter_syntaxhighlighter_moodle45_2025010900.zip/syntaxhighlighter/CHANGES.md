# Changes

## Version 2021052101

- Make turn-off-able
- Added test script to test
## Version 2020040201

- Added automated test scripts
## Version 2020040200

- Allow language to be specified #4

## Version 2017111302
*  added GDPR declaration
*  New setting to allow option of local or CDN served style sheets
*  Preview of selected style in settings page
