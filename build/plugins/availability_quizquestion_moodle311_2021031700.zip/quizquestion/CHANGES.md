# Change log for the estriction by single quiz question availability condition

## Changes in 1.2

* Correct a silly mistake with the version number.

## Changes in 1.1

* Fix a bug where the privacy provider code used the wrong namespace. (Thanks Luca Bösch.)


## Changes in 1.0

* Time to call this a stable release.
* Fixed a small bug with how the quiz name is formatted for output.


## Changes in 0.9.1

* Fix a bug with the description when 'not' was applied.
* Coding style fixes.


## Changes in 0.9.1

* Coding style fixes.


## First released version 0.9.0

* Initial working version of the plugin.
