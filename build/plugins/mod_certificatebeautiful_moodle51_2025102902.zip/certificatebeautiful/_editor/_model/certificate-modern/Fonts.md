## Licença:
https://www.freepik.com/free-vector/flat-design-modern-certificate-template_14485837.htm

## Fonts used in this design:

Font: Montserrat
Author: Julieta Ulanovsky,Sol Matas,Juan Pablo del Peral,Jacques Le Bailly
Url: https://fonts.google.com/specimen/Montserrat

Font: Open Sans
Author: Steve Matteson
Url: https://fonts.google.com/specimen/Open+Sans

Font: Lato
Author: Łukasz Dziedzic
Url: https://fonts.google.com/specimen/Lato