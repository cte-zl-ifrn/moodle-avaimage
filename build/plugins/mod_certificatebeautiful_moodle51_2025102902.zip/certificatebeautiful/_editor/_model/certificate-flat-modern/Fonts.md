Fonts used in this design:

Font: Inter
Author: Rasmus Andersson
Url: https://fonts.google.com/specimen/Inter

Font: Playfair Display
Author: Claus Eggers Sørensen
Url: https://fonts.google.com/specimen/Playfair+Display