Fonts used in this design:

Font: Alex Brush
Author: TypeSETit
Url: http://www.fontsquirrel.com/fonts/alex-brush

Font: Montserrat
Author: Julieta Ulanovsky
Url: http://www.fontsquirrel.com/fonts/montserrat

Font: Raleway
Author: The League of Moveable Type
Url: http://www.fontsquirrel.com/fonts/raleway