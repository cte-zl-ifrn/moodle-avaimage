Fonts used in this design:

Font: Cinzel
Author: Natanael Gama
Url: http://www.fontsquirrel.com/fonts/cinzel

Font: Raleway
Author: The League of Moveable Type
Url: http://www.fontsquirrel.com/fonts/raleway