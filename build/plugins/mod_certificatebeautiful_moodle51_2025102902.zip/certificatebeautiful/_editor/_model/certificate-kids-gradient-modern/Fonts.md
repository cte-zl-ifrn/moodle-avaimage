Fonts used in this design:

Font: Bebas Neue
Author: Ryoichi Tsunekawa
Url: https://fonts.google.com/specimen/Bebas+Neue

Font: Josefin Sans
Author: Santiago Orozco
Url: https://fonts.google.com/specimen/Josefin+Sans