Fonts used in this design:

Font: Poppins
Author: Indian Type Foundry,Jonny Pinhorn
Url: https://fonts.google.com/specimen/Poppins

Font: Montserrat
Author: Julieta Ulanovsky,Sol Matas,Juan Pablo del Peral,Jacques Le Bailly
Url: https://fonts.google.com/specimen/Montserrat

Font: Playfair Display
Author: Claus Eggers Sørensen
Url: https://fonts.google.com/specimen/Playfair+Display

Font: Pinyon Script
Author: Nicole Fally
Url: https://fonts.google.com/specimen/Pinyon+Script