Fonts used in this design:

Font: Abhaya Libre
Author: Mooniak
Url: https://fonts.google.com/specimen/Abhaya+Libre

Font: Poppins
Author: Indian Type Foundry,Jonny Pinhorn
Url: https://fonts.google.com/specimen/Poppins

Font: Alex Brush
Author: TypeSETit
Url: https://fonts.google.com/specimen/Alex+Brush