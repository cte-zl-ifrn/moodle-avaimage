## Licença:
https://www.freepik.com/free-vector/gradient-golden-luxury-certificate_17542181.htm

## Fonts used in this design:

Font: DM Serif Display
Author: Colophon Foundry,Frank Grießhammer
Url: https://fonts.google.com/specimen/DM+Serif+Display

Font: Parisienne
Author: Astigmatic
Url: https://fonts.google.com/specimen/Parisienne

Font: Open Sans
Author: Steve Matteson
Url: https://fonts.google.com/specimen/Open+Sans