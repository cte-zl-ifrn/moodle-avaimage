Fonts used in this design:

Font: Riffic
Author: Nini Prower
Url: http://www.fontsquirrel.com/fonts/riffic

Font: Poppins
Author: Indian Type Foundry
Url: https://www.fontsquirrel.com/fonts/poppins