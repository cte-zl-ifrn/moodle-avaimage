Fonts used in this design:

Font: Montserrat
Author: Julieta Ulanovsky
Url: http://www.fontsquirrel.com/fonts/montserrat

Font: Vibur
Author: Johan Kallas
Url: https://www.fontsquirrel.com/fonts/vibur