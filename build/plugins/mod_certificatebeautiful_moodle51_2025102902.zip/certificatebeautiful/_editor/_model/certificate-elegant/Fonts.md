## Licença:
https://www.freepik.com/free-vector/gradient-elegant-certificate-template_14834977.htm

## Fonts used in this design:

Font: Parisienne
Author: Astigmatic
Url: https://fonts.google.com/specimen/Parisienne

Font: Playfair Display
Author: Claus Eggers Sørensen
Url: https://fonts.google.com/specimen/Playfair+Display

Font: Lato
Author: Łukasz Dziedzic
Url: https://fonts.google.com/specimen/Lato