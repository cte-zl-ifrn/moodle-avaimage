Fonts used in this design: 

Third party Fonts: 

Font: Nunito 
Author: Vernon Adams,Cyreal 
Url: https://fonts.google.com/specimen/Nunito 

Font: Montserrat 
Author: Julieta Ulanovsky,Sol Matas,Juan Pablo del Peral,Jacques Le Bailly 
Url: https://fonts.google.com/specimen/Montserrat 

