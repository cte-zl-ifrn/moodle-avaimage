Fonts used in this design:

Font: Quicksand
Author: Andrew Paglinawan
Url: http://www.fontsquirrel.com/fonts/quicksand

Font: Caveat
Author: Impallari Type
Url: https://www.fontsquirrel.com/fonts/caveat