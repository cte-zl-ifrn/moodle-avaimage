A multi-selection profile field based on modern Moodle user interface widgets.

Available options are listed in a drop down menu. A text box provides filtering functionality. The list in the drop-down menu updates in real time to filter out options that don't match the filter text.

Selected options are displayed as tags.

Installation Instructions:
1. Unzip the directory and copy inside your-moodle /user /profile /field (at the end the folder structure should look like your-moodle/user/profile/field/autocomplete)
2. Log into Site as Admin user and go to site-administration -> Notification to perform installation.
3. After successful installation, you would find a new custom profile field type inside site administration -> user -> accounts -> user profile fields
4. Enjoy this new feature.
