<?php

defined('MOODLE_INTERNAL') || die();

$tasks = [
    [
        'classname' => 'profilefield_brasilufmunicipio\task\update_municipios',
        'blocking' => 0,
        'minute' => '0',
        'hour' => '1',
        'day' => '2',
        'month' => '*',
        'dayofweek' => '*',
    ],
];
