<?php
require_once($CFG->dirroot.'/user/lib.php');
