### availability_badge: Use badges to limit availability
-----------

##### This item adds the functionality that an activity in a course can be restricted by a badge in courses or site level.
-----------

Developed for [University Of Canberra](http://www.canberra.edu.au)

Tim Lock

Senior Software Engineer

[Blackboard Inc.](http://blackboard.com)
