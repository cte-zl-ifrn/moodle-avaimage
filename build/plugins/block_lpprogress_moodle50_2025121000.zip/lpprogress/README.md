# Learning Plans Progress #

This blocks shows the progress of learning plans in a vertical progress bar with "check" icons for each competency.

By clicking in the competency name  the user can see the list of linked courses and access the course by clicking on it's name.

https://moodle.org/plugins/block_lpprogress

## License ##

2021 Daniel Neis Araujo <daniel@adapta.online>

This program is free software: you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation, either version 3 of the License, or (at your option) any later
version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with
this program.  If not, see <http://www.gnu.org/licenses/>.
