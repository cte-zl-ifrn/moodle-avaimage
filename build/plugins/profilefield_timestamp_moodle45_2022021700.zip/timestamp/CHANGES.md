Release notes
=============

1. Keep minimum Moodle version supported as 2.5.
1. (#3) Use Github Actions to pass tests and update release on Moodle Plugins directory.
1. (#4) Added privacy metadata file.

Contributors
============

Maintained by:

* Jordi Pujol-Ahulló (at SREd, Universitat Rovira i Virgili).

[See all Github contributors](https://github.com/SREd-URV/moodle-profilefield_timestamp/graphs/contributors)
