Word count for Atto

QUICK INSTALL
=============
Put this entire directory at:

PATHTOMOODLE/lib/editors/atto/plugins/count

Visit your site notifications page to install the new plugins.

Add the "count" plugin to the Atto toolbar.
