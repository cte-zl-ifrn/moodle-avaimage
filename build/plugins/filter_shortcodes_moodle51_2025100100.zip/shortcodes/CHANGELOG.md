Changelog
=========

v1.1.2
------

- Compatibility with Moodle 5.1
- Minor coding style updates

v1.1.1
------

- Compatibility with Moodle 5.0
- Minor coding style updates

v1.1.0
------

- Compatibility with Moodle 4.5

v1.0.6
------

- Minor coding style updates

v1.0.5
------

- Built-in `[firstname]` shortcode escapes firstname

v1.0.4
------

- Filter is no longer automatically enabled in unit tests

v1.0.3
------

- Exception assertion in tests updated for latest PHP Unit

v1.0.2
------

- Include missing language string for cache definition

v1.0.1
------

- Implement privacy API
- Minor coding style changes

v1.0.0
------

- Initial release
