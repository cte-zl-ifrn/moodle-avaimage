
Release Notes
##### 2.0.2 (Build 2025052003)
Fixes:
* add missing change event
* fixes problems with grunt

##### 2.0.1 (Build 2025052000)
Fixes:  
* Wenn beim Aufruf des Editors verwaiste Dateien vorhanden sind aber KEINE Datei im Editor genutzt wurde, dann werden KEINERLEI verwaiste Dateien gefunden.
* Wenn man in Medien verwalten Dateien löscht und dann zurück in den Editor wechselt wird die Anzeige der verwaisten Dateien nicht aktualisiert.

##### 2.0.0 (Build 2025052000)
New features / improvements:

* issue #7: reduce ajax calls 
* issue #8: fix missing langstring for orphendfiles:view
* Enhance the orphendfiles:view permission to enable more granular access control.

##### 1.0.4 (Build 2024042600)
New features / improvements:

* add sorting
* some langfilefixes

##### 1.0.3 (Build 2024030102)
New features / improvements:

* add this file CHANGES.md for documentation


Big fixes:

* fix linter issues
* remove unused code



##### 1.0.2 (Build 2024030101)
New features / improvements:

* add this file CHANGES.md for documentation
* add workflow moodle-releases.yml


Big fixes:

* 


##### 1.0.1 (Build 2024030101)
New features / improvements:

*


Big fixes:

* grunt, codechecker, issues, ...



##### 1.0.1 (Build 2024030101)
New features / improvements:

*


Big fixes:

* grunt, codechecker, issues, ...


##### 1.0.0 (Build 2024021501)
New features / improvements:

* inital beta


Big fixes:

* 
