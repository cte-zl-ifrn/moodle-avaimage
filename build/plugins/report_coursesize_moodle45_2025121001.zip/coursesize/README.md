# Course Size Report 

This plugin provides approximate disk usage by Moodle courses. 


## Branches

| Moodle version    | Branch             |
| ----------------- | ------------------ |
| Moodle 4.1 to 4.5 | `MOODLE_401_STABLE` |

It should be possible to improve the report to address these issues - we'd greatly appreciate any patches to improve the plugin!

Copyright 2014 Catalyst IT http://www.catalyst.net.nz
