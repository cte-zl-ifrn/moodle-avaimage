define(['mod_imagemap/editor'], function(editor) {
    return {
        init: function() {
            editor.init();
        }
    };
});
