<?php
// Every file should have GPL and copyright in the header - we skip it in tutorials but you should not skip it for real.

// This line protects the file from being accessed by a URL directly.
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'theme_suap';
$plugin->release   = '0.1.018';
$plugin->version = 2025_11_02_001;
$plugin->maturity = MATURITY_STABLE;

$plugin->requires = 2016070700;
