# Changelog

## 4.5.4 - 2025-05-15
### Changed
- Only changes to automatic testing scripts

## 4.4.4 - 2024-10-08
### Added
- Compatibility with Moodle 4.5; Updates to version testing matrices

## 4.4.3 - 2024-09-03
### Changed
- Only changes to automatic testing scripts

## 4.4 - 2024-05-21
### Changed
- Only changes to the plugin release process

## 4.3.4 - 2024-04-23
### Added
- Compatibility with Moodle 4.4, added to the testing matrix

## 4.3 - 2023-11-09
### Added
- Testing on Workplace 4.3

## 4.2.3 - 2023-10-10
### Changed
- Coding style fixes
- Added LMS 4.3 and PHP 8.2 in the GHA testing matrix

## 4.2 - 2023-05-30
### Changed
- Only changes to automated tests

## 4.1.3 - 2023-04-25
### Added
- Compatibility with Moodle LMS 4.2
- Ensure compatibility with PHP 8.1 for Moodle LMS 4.1 and 4.2
### Changed
- Fixed exception when add-on plugins trigger events with properties of incorrect type

## 4.1.1 - 2023-01-17
### Changed
- Added testing branches (no functional changes)

## 4.0.5 - 2022-11-15
### Changed
- Added testing on LMS 4.1 (no functional changes)

## 4.0 - 2022-10-14
### Changed
- Minor changes in the automated testing scripts

## 3.11.6 - 2022-03-15
### Changed
- Minor changes in the automated testing scripts

## 3.11.5 - 2022-01-18
### Added
- First release of the Datewatch plugin by the Moodle Workplace team
