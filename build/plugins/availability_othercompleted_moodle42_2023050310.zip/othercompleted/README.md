# Moodle-availability_othercompleted

This plugin allow to restrict access of activities and resources in your course based on other course completion.

Documentation:-
https://www.mu.my/en/documentation/plugins/moodle-other-course-completion-restriction-plugin

Author:-
Sam Suresh

