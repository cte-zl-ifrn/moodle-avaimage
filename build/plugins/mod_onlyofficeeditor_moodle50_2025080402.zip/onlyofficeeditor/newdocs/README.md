## Overview

Template files used to create new documents and documents with sample content in:

- [ONLYOFFICE plugin for Moodle](https://github.com/ONLYOFFICE/moodle-mod_onlyofficeeditor)
- [ONLYOFFICE Docs Integration Java SDK](https://github.com/ONLYOFFICE/docs-integration-sdk-java)
- [ONLYOFFICE app for Confluence Cloud](https://github.com/ONLYOFFICE/onlyoffice-confluence-cloud)
- [ONLYOFFICE bot for Telegram](https://github.com/ONLYOFFICE/onlyoffice-telegram)
