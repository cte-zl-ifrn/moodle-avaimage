<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'onlyofficeeditor', language 'it'.
 *
 * @package     mod_onlyofficeeditor
 * @subpackage
 * @copyright   2025 Ascensio System SIA <integration@onlyoffice.com>
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
$string['banner_description'] = 'Avvia facilmente gli editor nel cloud senza scaricarli e installarli';
$string['banner_link_title'] = 'Ottieni ora';
$string['banner_title'] = 'ONLYOFFICE Docs nel Cloud';
$string['checkdocserverbutton'] = 'Verifica connessione a Docs';
$string['connectionerror'] = 'Errore di connessione';
$string['connectionerror:command'] = 'Errore durante la verifica di CommandService';
$string['connectionerror:convert'] = 'Errore durante la verifica di ConvertService';
$string['connectionerror:unexpected'] = 'Si è verificato un errore imprevisto durante la verifica della connessione';
$string['connectionsuccess'] = 'La connessione è stabil';
$string['disable_verify_ssl'] = 'Disattiva la verifica del certificato (non sicuro)';
$string['disable_verify_ssl:description'] = 'Usare solo quando si accede a Document Server con un certificato autofirmato';
$string['docserverunreachable'] = 'ONLYOFFICE Document Server non può essere raggiunto. Contatta amministratore';
$string['documentpermissions'] = 'Autorizzazioni per documenti';
$string['documentservererror'] = 'Impossibile connettersi a ONLYOFFICE Docs. Controlla che il server sia attivo e accessibile.';
$string['documentserverinternal'] = 'Indirizzo di ONLYOFFICE Docs per le richieste interne del server';
$string['documentserverinternal:description'] = 'Compila solo se utilizzi il routing interno tra il server Moodle e ONLYOFFICE Docs, senza fare affidamento su indirizzi pubblici';
$string['documentserversecret'] = 'Chiave di Document Server';
$string['documentserversecret_desc'] = 'Chiave segreta viene utilizzata per generare il token (una firma crittografata) nel browser per aprire l\'editor di documenti e chiamare i metodi e le richieste al servizio di comando documenti e al servizio di conversione documenti. Il token impedisce la sostituzione di parametri importanti nelle richieste di ONLYOFFICE Document Server.';
$string['documentserverurl'] = 'Indirizzo del servizio di modifica documenti';
$string['documentserverurl_desc'] = 'Indirizzo del servizio di modifica documenti specifica l\'indirizzo del server con i servizi documenti installati. Sostituisci \'https://documentserver.url\' sopra con l\'indirizzo corretto del server';
$string['docxformname'] = 'Documento';
$string['download'] = 'E possibile scaricare documento';
$string['download_help'] = 'Se è disabilitata gli documenti non saranno scaricabili tramite l\'editor ONLYOFFICE. Nota: gli utenti con la funzionalità <strong>course:manageactivities</strong> possono sempre scaricare i documenti tramite l\'applicazione.';
$string['editor_security'] = 'Sicurezza';
$string['editor_security_macros'] = 'Esegui le macro del documento';
$string['editor_security_plugin'] = 'Abilitare plugin';
$string['editor_view'] = 'Impostazioni di personalizzazione dell\'editor';
$string['editor_view_chat'] = 'Visualizza il pulsante del menu Chat';
$string['editor_view_description'] = 'Scopri di più sulla personalizzazione dell\'editor <a href="{$a->url}" target="_blank">qui</a>.';
$string['editor_view_feedback'] = 'Visualizza il pulsante del menu Feedback e Supporto';
$string['editor_view_header'] = 'Visualizza l\'intestazione più compatta';
$string['editor_view_help'] = 'Visualizza il pulsante del menu Guida';
$string['editor_view_toolbar'] = 'Visualizza intestazione della barra degli strumenti monocromatica';
$string['editorenterfullscreen'] = 'Apri la modalità schermo intero';
$string['editorexitfullscreen'] = 'Esci dalla modalità schermo intero';
$string['forcesave'] = 'Abilita salvataggio forzato';
$string['jwtheader'] = 'Intestazione di autorizzazione';
$string['mentioncontexturlname'] = 'Link al commento.';
$string['mentionnotifier:notification'] = '{$a->notifier} menzionato nel {$a->course}';
$string['messageprovider:mentionnotifier'] = 'Notifica della menzione di ONLYOFFICE nel modulo Documenti.';
$string['modulename'] = 'Documento ONLYOFFICE';
$string['modulename_help'] = 'Modulo ONLYOFFICE consente di creare e modificare i documenti di office archiviati localmente in Moodle utilizzando ONLYOFFICE Document Server, permette a più utenti di collaborare in tempo reale e di salvare le modifiche in Moodle

Per scoprire di più, visita <a href="https://helpcenter.onlyoffice.com/integration/moodle.aspx" target="_blank">Centro Assistenza</a>.';
$string['modulenameplural'] = 'Documenti ONLYOFFICE';
$string['oldversion'] = 'Si prega di aggiornare ONLYOFFICE Docs alla versione 7.0 per lavorare su moduli compilabili online';
$string['onlyofficeactivityicon'] = 'Aprire in ONLYOFFICE';
$string['onlyofficeeditor:addinstance'] = 'Aggiungi una nuova attività Documenti ONLYOFFICE';
$string['onlyofficeeditor:editdocument'] = 'Modifica l\'attività Documenti ONLYOFFICE';
$string['onlyofficeeditor:view'] = 'Visualizza l\'attività Documenti ONLYOFFICE';
$string['onlyofficename'] = 'Nome dell\'attività';
$string['onmentionerror'] = 'Errore nel menzionare.';
$string['pdfformname'] = 'Modulo PDF';
$string['pluginadministration'] = 'Amministrazione dell\'attività Documenti di ONLYOFFICE';
$string['pluginname'] = 'Documento ONLYOFFICE';
$string['pptxformname'] = 'Presentazione';
$string['print'] = 'E possibile stampare il documento';
$string['print_help'] = 'Se è disabilitata, gli documenti non saranno stampabili tramite l\'editor ONLYOFFICE. Nota: gli utenti con la funzionalità <strong>course:manageactivities</strong> possono sempre stampare i documenti tramite l\'applicazione.';
$string['privacy:metadata'] = 'Nessuna informazione sui dati personali degli utenti viene memorizzata.';
$string['privacy:metadata:onlyofficeeditor'] = 'Informazioni sui documenti modificati con ONLYOFFICE.';
$string['privacy:metadata:onlyofficeeditor:core_files'] = 'Attività Documenti ONLYOFFICE memorizza i documenti che sono stati modificati.';
$string['privacy:metadata:onlyofficeeditor:course'] = 'Corso a cui appartiene l\'attività ONLYOFFICE';
$string['privacy:metadata:onlyofficeeditor:intro'] = 'Introduzione generale dell\'attività ONLYOFFICE';
$string['privacy:metadata:onlyofficeeditor:introformat'] = 'Formato del campo intro (MOODLE, HTML, MARKDOWN...).';
$string['privacy:metadata:onlyofficeeditor:name'] = 'Nome dell\'attività ONLYOFFICE.';
$string['privacy:metadata:onlyofficeeditor:permissions'] = 'Autorizzazioni per documenti.';
$string['privacy:metadata:onlyofficeeditor:userid'] = 'L\'effettivo ID utente non viene inviato all\'editor ONLYOFFICE.';
$string['protect'] = 'Nascondere la scheda Protezione';
$string['protect_help'] = 'Se è disabilitata, gli utenti hanno accesso alle impostazioni di protezione nell\'editor ONLYOFFICE. Nota: gli utenti con la funzionalità <strong>course:manageactivities</strong> hanno sempre accesso alle impostazioni di protezione.';
$string['readmore'] = 'Più informazioni';
$string['returntodocument'] = 'Torna alla pagina del corso';
$string['saveasbutton'] = 'Seleziona';
$string['saveaserror'] = 'Qualcosa è andato storto.';
$string['saveassuccess'] = 'Il documento è stato salvato con successo.';
$string['saveastitle'] = 'Seleziona la sezione del corso per salvare il documento';
$string['savewarning'] = 'Non dimenticare di salvare le modifiche in fondo alla pagina';
$string['selectfile'] = 'Seleziona il file esistente o creane uno nuovo cliccando una delle icone';
$string['settingsintro'] = 'Modifica e collabora su documenti office online direttamente nella struttura del corso Moodle. Condividi documenti per la visualizzazione o la modifica collaborativa in tempo reale. Crea, condividi e valuta i compiti degli studenti.';
$string['storageurl'] = 'Indirizzo del server per le richieste interne da ONLYOFFICE Docs';
$string['suggestfeature'] = 'Suggerisci una funzionalità';
$string['unsupportedfileformat'] = 'Formato file non supportato';
$string['uploadformname'] = 'Carica file';
$string['validationerror:apijsunavailable'] = 'Impossibile recuperare il file JavaScript delle API.';
$string['validationerror:docsinvalidurl'] = 'L\'URL di Document Server non è valido. Controlla il formato dell\'URL.';
$string['validationerror:documentserverunreachable'] = 'Impossibile connettersi a ONLYOFFICE Docs. Verifica che il server sia in esecuzione e accessibile.';
$string['validationerror:emptyurl'] = 'L\'URL di ONLYOFFICE Docs non può essere vuoto.';
$string['validationerror:incorrectjwtheader'] = 'Impossibile connettersi a ONLYOFFICE Docs. Verifica che l\'intestazione di autorizzazione sia corretta.';
$string['validationerror:incorrectsecret'] = 'Impossibile connettersi a ONLYOFFICE Docs. Controlla che la chiave segreta sia corretta.';
$string['validationerror:invalidurl'] = 'L\'URL non è valido. Controlla il formato dell\'URL.';
$string['validationerror:mixedcontent'] = 'Il contenuto attivo misto non è consentito. È richiesto l\'indirizzo HTTPS per ONLYOFFICE Docs.';
$string['xlsxformname'] = 'Foglio di calcolo';
