Moodle Mobile app availabilty plugin
====================================

Control module and section access for Moodle Mobile app.

With this plugin you can choose if an activity, resource or a complete section is (or is not) visible for users accesing the course via the Mobile app.

Once installed you can create Moodle Mobile friendly courses just replacing resources currently not supported by the app, like the Book module, with Mobile friendly resources (like an HTML version of the book module).

For Moodle 3.10 and bellow please use the MOODLE_310_STABLE branch
