## Program certificate

If tool_certificate is installed then program management interface shows option to select
certificate template which is then used to issue certificates to users that complete
the program.

To enable certificate issuing following plugins need to be installed:

* [moodle-tool_certificate](https://github.com/moodleworkplace/moodle-tool_certificate)
* [moodle-certificateelement_programs](https://github.com/open-lms-open-source/moodle-certificateelement_programs)

_See [Program management overview](management.md) for more information._
