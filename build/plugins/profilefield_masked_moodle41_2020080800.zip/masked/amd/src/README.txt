jQuery Mask Plugin
--------------

Description of jQuery Mask Plugin Copyright (c) Igor Escobar on 2012-03-10.

This Font Software is licensed under the MIT.

To upgrade this library:
1. Download the latest release of jQuery Mask Plugin in https://github.com/igorescobar/jQuery-Mask-Plugin.
2. Remove mask.js file from amd/src.
3. Copy dist/jquery.mask.js to amd/src.
4. Adjust to work as a AMD module
5. Run moodle grunt to build the file.
6. Update thirdpartylibs.xml.
