# block_multiprogress

Design: https://xd.adobe.com/view/e0cfadb2-e6eb-42c7-b4b3-78202cf32443-b59c/ e em assets/img/design.jpg