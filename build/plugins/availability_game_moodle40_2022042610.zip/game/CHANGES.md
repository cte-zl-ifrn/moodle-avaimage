moodle-availability_game
========================

Changes
-------
### Changes Version 1.1.0 Version for Moodle 3.4 onwards

* 2022-04-26 - **Compatibility with moodle 4.0**
* 2022-04-26 - **Adaptation to 15 levels**

### Changes Version 1.0.0 for Moodle 3.4 onwards (2021042124)

* 2021-04-08 - Change plugin version and release scheme to the scheme promoted by moodle.org, no functionality change
* 2021-01-05 - Initial version
