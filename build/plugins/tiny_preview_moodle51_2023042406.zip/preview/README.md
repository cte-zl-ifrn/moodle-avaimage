tiny_preview
=================

This is a plugin for Tiny editor in Moodle that allows it to
display a preview modal. The content of the editor are passed
through appropriate Moodle text filters.  To install unpack to
lib/editor/tiny/plugins/preview, and visit the admin notifications page
to install.

All original files are copyright Daniel Thies 2022 dethies@gmail.com
onward and are licensed under the included GPL 3.
