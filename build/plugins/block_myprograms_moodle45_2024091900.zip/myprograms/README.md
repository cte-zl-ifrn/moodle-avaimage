# Overview

This block is part of _Programs for Moodle_ by Open LMS,
see [moodle-enrol_programs](https://github.com/open-lms-open-source/moodle-enrol_programs)
plugin for more information.
