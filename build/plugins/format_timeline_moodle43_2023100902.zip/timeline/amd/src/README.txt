SweetAlert2
--------------

Description of SweetAlert2 Copyright (c) 2014 Tristan Edwards & Limon Monte.

This Font Software is licensed under the MIT.

To upgrade this library:
1. Download the latest release of SweetAlert2 in https://github.com/sweetalert2/sweetalert2.
2. Remove sweetalert.js file from amd/src.
3. Copy dist/sweetalert.js to amd/src.
4. Adjust to work as a AMD module
5. Run moodle grunt to build the file.
6. Update thirdpartylibs.xml.

Tribute
--------------

Description of Tribute Copyright (c) 2017-2020 ZURB, Inc. Copyright (c) 2014 Jeff Collins, Copyright (c) 2012 Matt York.

This Font Software is licensed under the MIT License (MIT).

To upgrade this library:
1. Download the latest release of Tribute in https://github.com/zurb/tribute.
2. Remove the tribute.js files from amd/src.
3. Copy dist/tribute.js to amd/src.
4. Adjust to work as a AMD module
5. Run moodle grunt to build the file.
6. Update thirdpartylibs.xml.
