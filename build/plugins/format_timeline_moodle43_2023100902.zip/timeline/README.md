Timeline Course Format
==========================
A simple timeline to simule a real social network course in moodle

About this project
==========================

This is a crowdfunding project financed by the power and help of the Moodle community.

Donators
==========================

Special thanks for you all, you made this happen. S2

* ALEX CESARIO DE OLIVEIRA
* ANDERSON BLAINE
* ANDRE GENESINI
* ANTONIO CARLOS COSTA
* ARIANA C ALCANTARA
* CHRIS KENNIBURG
* DANIEL CAIXETA QUEIROZ GARCIA
* DANIEL NEIS ARAUJO
* DANILO CUNHA
* DAVID MELO DA LUZ
* EDUARDO ROMCY PEREIRA
* FABIO LIMA
* GIOVANNI FARIAS
* GISELE R BRUGGER
* HILDE SILVANA PONTES
* INICIATIVA EDUCAÇÃO ABERTA
* IRANDY MARCOS CRUZ
* JANAINA COSTA
* JOHN MWAURA
* JONAS MENDES
* JOSÉ ERLAN
* JOSÉ MARCIO LACERDA
* KAREN IGLESIAS
* KATYUSCIA SOSNOWSKI
* LEANDRO BARBOSA RODRIGUES
* LUSANA VERÍSSIMO
* MARCIA LOTITO
* MARCOS PAULO SALES DOS SANTOS
* NATALIE ALVES
* ORLIVALDO KLÉBER LIMA RIOS
* PAULO WAGNER
* PRISCILA GONSALES
* SEBALE
* SERGIO PAIBA
* SUSHUMNARAO T
* WALLACE P CARDOZO

Developed and maintained by
===========================

Willian Mano

* Zend Certified PHP Engineer - ZEND028770
* Certified Scrum Master - 000570341
* iMasters Certified Professional - PHP - Good Practices - 1076

Moodle profile: https://moodle.org/user/profile.php?id=968235

Linkedin: https://www.linkedin.com/in/willianmano

Installation
===========================

**First way**

* Clone this repository into the course/format folder with the name timeline.
* Access the notification area in moodle and install

**Second way**

* Download this repository
* Extract the content
* Put the folder into the folder course/format with the name timeline.
* Access the notification area in moodle and install

