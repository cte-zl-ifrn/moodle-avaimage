# WidgetHub unit modules testing

The purporse of this directory is to provide a way to test javascript modules in isolation using jest framework.

## Run tests

- `cd` in the jsunit directory
- `npm install`, to download dependencies
- `npm run link`, to create a symbolic link to the src folder
- `npm run test`, to start the tests

## Coverage reports

Coverage can be found in the coverage folder. Just open `index.html` file