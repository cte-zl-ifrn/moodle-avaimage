<?php

/**
 * Plugin administration pages are defined here.
 *
 * @package     block_course_rating
 * @category    block
 * @copyright   2025 Daniel Morais <danielbergmorais@gmail.com>
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

if ($hassiteconfig) {
    if ($ADMIN->fulltree) {
    }
}
