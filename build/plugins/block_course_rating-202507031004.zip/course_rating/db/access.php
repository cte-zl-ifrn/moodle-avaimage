<?php
defined('MOODLE_INTERNAL') || die();
