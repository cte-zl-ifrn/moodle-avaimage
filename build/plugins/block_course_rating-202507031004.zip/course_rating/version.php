<?php

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'block_course_rating';
$plugin->release = '1.4';
$plugin->version = 202507031004;
$plugin->requires = 2021051700;
$plugin->maturity = MATURITY_STABLE;
