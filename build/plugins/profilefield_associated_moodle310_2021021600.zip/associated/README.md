Ever wondered how to include a core optional profile field on the signup page? Or how to make that field a required field?
Or even how to prevent users to provide a non-unique value for it?

The associated profile field is the answer to your need. You can define an associated profile field and "associate" it with a core profile field.