To build on windows use
 
    grunt js --root=report/extendedlog