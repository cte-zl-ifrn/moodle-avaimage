CHANGELOG
=========

v1.2.3
------

- Compatibility with PHP 8.4
- Raised minimum required version to Moodle 3.7
- PHP 7.1 required through Moodle 3.7 requirement

v1.2.2
------

- Requiring zero-quantity did not always work
- Minor coding style adjustments
- Deprecate unused method get_generic_description

v1.2.1
------

- Styling improvements across themes

v1.2.0
------

- Change maturity to stable (long due)
- Implement privacy API (GDPR compliance)