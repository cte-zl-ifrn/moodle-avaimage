<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'calendarsystem_jalali', language 'pt_br', version '4.5'.
 *
 * @package     calendarsystem_jalali
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['am'] = 'am';
$string['am_caps'] = 'AM';
$string['month1'] = 'Farvardin';
$string['month10'] = 'Dey';
$string['month11'] = 'Bahman';
$string['month12'] = 'Esfand';
$string['month2'] = 'Ordibehesht';
$string['month3'] = 'Khordad';
$string['month4'] = 'Tir';
$string['month5'] = 'Mordad';
$string['month6'] = 'Shahrivar';
$string['month7'] = 'Mehr';
$string['month8'] = 'Aban';
$string['month9'] = 'Azar';
$string['name'] = 'Persian';
$string['pluginname'] = 'Sistema de calendário Persa';
$string['pm'] = 'pm';
$string['pm_caps'] = 'PM';
$string['weekday0'] = 'Domingo';
$string['weekday1'] = 'Segunda-feira';
$string['weekday2'] = 'Terça-feira';
$string['weekday3'] = 'Quarta-feira';
$string['weekday4'] = 'Quinta-feira';
$string['weekday5'] = 'Sexta-feira';
$string['weekday6'] = 'Sábado';
