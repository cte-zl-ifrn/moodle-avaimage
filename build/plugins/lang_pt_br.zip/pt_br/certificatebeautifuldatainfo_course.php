<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'certificatebeautifuldatainfo_course', language 'pt_br', version '4.5'.
 *
 * @package     certificatebeautifuldatainfo_course
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['category'] = 'O identificador da categoria à qual o curso pertence.';
$string['enddate'] = 'A data de término do curso.';
$string['fullname'] = 'O nome completo do curso.';
$string['id'] = 'Um identificador único para cada curso.';
$string['lang'] = 'O idioma do curso.';
$string['modules'] = 'Lista de seções e módulos do curso';
$string['pluginname'] = 'Dados do curso para o qual o certificado está sendo gerado';
$string['privacy:metadata'] = 'O plugin não armazena nenhum dado pessoal.';
$string['sections'] = 'Lista de seções do curso (apenas Sessões Nomeadas personalizadas)';
$string['shortname'] = 'Um nome curto ou código único para o curso.';
$string['startdate'] = 'A data de início do curso.';
$string['summary'] = 'O resumo do curso definido na configuração do curso';
