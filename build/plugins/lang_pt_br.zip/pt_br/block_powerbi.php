<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_powerbi', language 'pt_br', version '4.5'.
 *
 * @package     block_powerbi
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['actions'] = 'Ações';
$string['addfilters'] = 'Adicionar {nenhum} filtros a mais';
$string['addingreport'] = 'Adicionando novo relatório';
$string['addreport'] = 'Adicionar novo relatório';
$string['applybase64'] = 'Aplicar codificação base64 ao valor do parâmetro';
$string['clientid'] = 'ID do cliente';
$string['clientiddesc'] = 'O ID do cliente fornecido pelo Power BI';
$string['clientsecret'] = 'Chave Secreta';
$string['clientsecretdesc'] = 'Chave Secreta do Cliente fornecida pelo Power BI';
$string['cohorts'] = 'Coortes';
$string['confirmdeletereport'] = 'Tem certeza de que deseja excluir este relatório? Esta ação não pode ser desfeita.';
$string['editingreport'] = 'Editando relatório';
$string['filter'] = 'Filtro';
$string['managereports'] = 'Gerenciar relatórios';
$string['pluginname'] = 'Power BI';
$string['powerbi:addinstance'] = 'Adicionar instância do powerbi';
$string['powerbi:managereports'] = 'Gerenciar relatórios';
$string['powerbi:myaddinstance'] = 'Adicionar instância do powerbi ao painel';
$string['powerbi:viewreports'] = 'Ver relatórios';
$string['privacy:metadata'] = 'O Power BI bloqueia, mas não armazena nenhum dado pessoal.';
$string['reportadded'] = 'Relatório adicionado com sucesso';
$string['reportdatasetid'] = 'ID do conjunto de dados';
$string['reportdeleted'] = 'Relatório excluído';
$string['reportname'] = 'Nome do relatório';
$string['reportreportid'] = 'ID do relatório';
$string['reportupdated'] = 'Relatório atualizado';
$string['reportworkspaceid'] = 'ID da área de trabalho';
$string['tenant'] = 'Ambiente';
$string['tenantdesc'] = 'O Ambiente da sua organização fornecido pelo Power BI';
$string['title'] = 'Título do bloco';
$string['titledesc'] = 'Isto será usado como título do bloco como cabeçalhos de página';
$string['viewingembeddedreport'] = 'Visualizando relatório incorporado';
