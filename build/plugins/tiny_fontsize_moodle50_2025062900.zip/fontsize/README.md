# moodle-tiny_fontsize
Tiny editor font size plugin.

Plugin allows users to change their text's font size.
