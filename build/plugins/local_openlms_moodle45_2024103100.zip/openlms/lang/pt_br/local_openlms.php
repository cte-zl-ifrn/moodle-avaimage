<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Open LMS local extras plugin.
 *
 * @package    local_openlms
 * @copyright  2022 Open LMS (https://www.openlms.net/)
 * @author     Petr Skoda
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['extramenu'] = 'Ações extras';
$string['notification'] = 'Notificação';
$string['notification_body'] = 'Mensagem';
$string['notification_create'] = 'Adicionar notificação';
$string['notification_custom'] = 'Personalizada';
$string['notification_delete'] = 'Excluir notificação';
$string['notification_delete_confirm'] = 'Se a instância de notificação for excluída e adicionada novamente mais tarde, é possível que os usuários sejam notificados repetidamente.';
$string['notification_enabled'] = 'Ativado';
$string['notification_extramenu'] = 'Ações de notificação';
$string['notification_import'] = 'Importar notificações';
$string['notification_import_from'] = 'Importar de';
$string['notification_instance'] = 'Notificação para';
$string['notification_subject'] = 'Assunto';
$string['notification_type'] = 'Tipo de notificação';
$string['notification_types'] = 'Tipos de notificação';
$string['notification_update'] = 'Notificações de atualização';
$string['notification_view'] = 'Detalhes de notificação';
$string['notifications'] = 'Notificações';
$string['pluginname'] = 'Utilitários do Open LMS';
$string['privacy:metadata:userid'] = 'Usuário';
$string['privacy:metadata:local_openlms_user_notified:tableexplanation'] = 'Rastreamento de notificações do usuário';
$string['toomanyrecords'] = 'Muitos registros encontrados';
