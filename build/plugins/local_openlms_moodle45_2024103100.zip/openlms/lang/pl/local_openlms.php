<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Open LMS local extras plugin.
 *
 * @package    local_openlms
 * @copyright  2022 Open LMS (https://www.openlms.net/)
 * @author     Petr Skoda
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['extramenu'] = 'Akcje dodatkowe';
$string['notification'] = 'Powiadomienie';
$string['notification_body'] = 'Wiadomość';
$string['notification_create'] = 'Dodaj powiadomienie';
$string['notification_custom'] = 'Dostosowane';
$string['notification_delete'] = 'Usuń powiadomienie';
$string['notification_delete_confirm'] = 'Jeśli instancja powiadomienia zostanie usunięta, a następnie dodana ponownie, użytkownicy mogą być powiadamiani wielokrotnie.';
$string['notification_enabled'] = 'Włączono';
$string['notification_extramenu'] = 'Akcje powiadomień';
$string['notification_import'] = 'Importuj powiadomienia';
$string['notification_import_from'] = 'Importuj z';
$string['notification_instance'] = 'Powiadomienie dla';
$string['notification_subject'] = 'Temat';
$string['notification_type'] = 'Typ powiadomienia';
$string['notification_types'] = 'Typy powiadomień';
$string['notification_update'] = 'Aktualizuj powiadomienie';
$string['notification_view'] = 'Szczegóły powiadomienia';
$string['notifications'] = 'Powiadomienia';
$string['pluginname'] = 'Narzędzia Open LMS';
$string['privacy:metadata:userid'] = 'Użytkownik';
$string['privacy:metadata:local_openlms_user_notified:tableexplanation'] = 'Śledzenie powiadomień użytkownika';
$string['toomanyrecords'] = 'Znaleziono zbyt wiele rekordów';
