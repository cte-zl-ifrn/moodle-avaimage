<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Open LMS local extras plugin.
 *
 * @package    local_openlms
 * @copyright  2022 Open LMS (https://www.openlms.net/)
 * @author     Petr Skoda
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['extramenu'] = 'Zusätzliche Aktionen';
$string['notification'] = 'Benachrichtigung';
$string['notification_body'] = 'Nachricht';
$string['notification_create'] = 'Benachrichtigung hinzufügen';
$string['notification_custom'] = 'Angepasst';
$string['notification_delete'] = 'Benachrichtigung löschen';
$string['notification_delete_confirm'] = 'Wenn die Benachrichtigungsinstanz gelöscht und später erneut hinzugefügt wird, werden Nutzer/innen möglicherweise wiederholt benachrichtigt.';
$string['notification_enabled'] = 'Aktiviert';
$string['notification_extramenu'] = 'Benachrichtigungsaktionen';
$string['notification_import'] = 'Benachrichtigungen importieren';
$string['notification_import_from'] = 'Import von';
$string['notification_instance'] = 'Benachrichtigung für';
$string['notification_subject'] = 'Betreff';
$string['notification_type'] = 'Benachrichtigungstyp';
$string['notification_types'] = 'Benachrichtigungstypen';
$string['notification_update'] = 'Benachrichtigung aktualisieren';
$string['notification_view'] = 'Benachrichtigungsdetails';
$string['notifications'] = 'Benachrichtigungen';
$string['pluginname'] = 'Open LMS-Tools';
$string['privacy:metadata:userid'] = 'Nutzer/in';
$string['privacy:metadata:local_openlms_user_notified:tableexplanation'] = 'Nachverfolgung von Nutzer/innenbenachrichtigungen';
$string['toomanyrecords'] = 'Zu viele Datensätze gefunden';
