<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Open LMS local extras plugin.
 *
 * @package    local_openlms
 * @copyright  2022 Open LMS (https://www.openlms.net/)
 * @author     Petr Skoda
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['extramenu'] = 'Accions addicionals';
$string['notification'] = 'Notificació';
$string['notification_body'] = 'Missatge';
$string['notification_create'] = 'Afegeix una notificació';
$string['notification_custom'] = 'S\'ha personalitzat';
$string['notification_delete'] = 'Suprimeix la notificació';
$string['notification_delete_confirm'] = 'Si se suprimeix la instància de notificació i es torna a afegir més tard, és possible que els usuaris rebin notificacions repetides.';
$string['notification_enabled'] = 'S\'ha habilitat';
$string['notification_extramenu'] = 'Accions de notificació';
$string['notification_import'] = 'Notificacions d\'importació';
$string['notification_import_from'] = 'Importa de';
$string['notification_instance'] = 'Notificació per a';
$string['notification_subject'] = 'Assumpte';
$string['notification_type'] = 'Tipus de notificació';
$string['notification_types'] = 'Tipus de notificacions';
$string['notification_update'] = 'Actualitza la notificació';
$string['notification_view'] = 'Detalls de la notificació';
$string['notifications'] = 'Notificacions';
$string['pluginname'] = 'Utilitats d\'Open LMS';
$string['privacy:metadata:userid'] = 'Usuari';
$string['privacy:metadata:local_openlms_user_notified:tableexplanation'] = 'Seguiment de les notificacions d\'usuari';
$string['toomanyrecords'] = 'S\'han trobat massa registres';
