<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Open LMS local extras plugin.
 *
 * @package    local_openlms
 * @copyright  2022 Open LMS (https://www.openlms.net/)
 * @author     Petr Skoda
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['extramenu'] = 'Actions supplémentaires';
$string['notification'] = 'Notification';
$string['notification_body'] = 'Message';
$string['notification_create'] = 'Ajouter une notification';
$string['notification_custom'] = 'Personnalisé';
$string['notification_delete'] = 'Supprimer une notification';
$string['notification_delete_confirm'] = 'Si l\'instance de notification est supprimée, puis rajoutée, les utilisateurs peuvent être avertis à plusieurs reprises.';
$string['notification_enabled'] = 'Activé';
$string['notification_extramenu'] = 'Actions de notification';
$string['notification_import'] = 'Importer des notifications';
$string['notification_import_from'] = 'Importer à partir de';
$string['notification_instance'] = 'Notification pour';
$string['notification_subject'] = 'Objet';
$string['notification_type'] = 'Type de notification';
$string['notification_types'] = 'Types de notification';
$string['notification_update'] = 'Mettre à jour la notification';
$string['notification_view'] = 'Détails de la notification';
$string['notifications'] = 'Notifications';
$string['pluginname'] = 'Utilitaires Open LMS';
$string['privacy:metadata:userid'] = 'Utilisateur';
$string['privacy:metadata:local_openlms_user_notified:tableexplanation'] = 'Suivi de notification utilisateur';
$string['toomanyrecords'] = 'Trop d\'enregistrements trouvés';
