<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Open LMS local extras plugin.
 *
 * @package    local_openlms
 * @copyright  2022 Open LMS (https://www.openlms.net/)
 * @author     Petr Skoda
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['extramenu'] = '額外動作';
$string['notification'] = '通知';
$string['notification_body'] = '訊息';
$string['notification_create'] = '新增通知';
$string['notification_custom'] = '已自訂';
$string['notification_delete'] = '刪除通知';
$string['notification_delete_confirm'] = '如果刪除通知例項之後再次加以新增，使用者就可能重複收到通知。';
$string['notification_enabled'] = '已啟用';
$string['notification_extramenu'] = '通知動作';
$string['notification_import'] = '匯入通知';
$string['notification_import_from'] = '匯入來源';
$string['notification_instance'] = '通知用於';
$string['notification_subject'] = '主旨';
$string['notification_type'] = '通知類型';
$string['notification_types'] = '通知類型';
$string['notification_update'] = '更新通知';
$string['notification_view'] = '通知詳細資料';
$string['notifications'] = '通知';
$string['pluginname'] = 'Open LMS 公用程式';
$string['privacy:metadata:userid'] = '使用者';
$string['privacy:metadata:local_openlms_user_notified:tableexplanation'] = '使用者通知追蹤';
$string['toomanyrecords'] = '找到太多筆記錄';
