<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Open LMS local extras plugin.
 *
 * @package    local_openlms
 * @copyright  2022 Open LMS (https://www.openlms.net/)
 * @author     Petr Skoda
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['extramenu'] = 'Další akce';
$string['notification'] = 'Oznámení';
$string['notification_body'] = 'Zpráva';
$string['notification_create'] = 'Přidat oznámení';
$string['notification_custom'] = 'Přizpůsobit';
$string['notification_delete'] = 'Odstranit oznámení';
$string['notification_delete_confirm'] = 'Je-li instance oznámení odstraněna a poté znovu přidána, je možné uživatelům zaslat oznámení opakovaně.';
$string['notification_enabled'] = 'Povoleno';
$string['notification_extramenu'] = 'Akce oznámení';
$string['notification_import'] = 'Importovat oznámení';
$string['notification_import_from'] = 'Importovat z';
$string['notification_instance'] = 'Oznámení pro';
$string['notification_subject'] = 'Předmět';
$string['notification_type'] = 'Typ oznámení';
$string['notification_types'] = 'Typy oznámení';
$string['notification_update'] = 'Oznámení o aktualizaci';
$string['notification_view'] = 'Podrobnosti oznámení';
$string['notifications'] = 'Oznámení';
$string['pluginname'] = 'Nástroje Open LMS';
$string['privacy:metadata:userid'] = 'Uživatel';
$string['privacy:metadata:local_openlms_user_notified:tableexplanation'] = 'Sledování oznámení uživatele';
$string['toomanyrecords'] = 'Nalezeno příliš mnoho záznamů';
