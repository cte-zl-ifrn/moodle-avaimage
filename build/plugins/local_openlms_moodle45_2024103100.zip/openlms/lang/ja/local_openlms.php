<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Open LMS local extras plugin.
 *
 * @package    local_openlms
 * @copyright  2022 Open LMS (https://www.openlms.net/)
 * @author     Petr Skoda
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['extramenu'] = '追加のアクション';
$string['notification'] = '通知';
$string['notification_body'] = 'メッセージ';
$string['notification_create'] = '通知を追加する';
$string['notification_custom'] = 'カスタマイズ済み';
$string['notification_delete'] = '通知を削除する';
$string['notification_delete_confirm'] = '通知のインスタンスが削除された後で再度追加された場合、ユーザは繰り返し通知を受ける可能性があります。';
$string['notification_enabled'] = '有効';
$string['notification_extramenu'] = '通知アクション';
$string['notification_import'] = '通知をインポートする';
$string['notification_import_from'] = 'インポート元';
$string['notification_instance'] = '通知内容';
$string['notification_subject'] = '件名';
$string['notification_type'] = '通知タイプ';
$string['notification_types'] = '通知タイプ';
$string['notification_update'] = '更新通知';
$string['notification_view'] = '通知の詳細';
$string['notifications'] = '通知';
$string['pluginname'] = 'Open LMSのユーティリティ';
$string['privacy:metadata:userid'] = 'ユーザ';
$string['privacy:metadata:local_openlms_user_notified:tableexplanation'] = 'ユーザ通知のトラッキング';
$string['toomanyrecords'] = '見つかったレコードが多すぎます';
