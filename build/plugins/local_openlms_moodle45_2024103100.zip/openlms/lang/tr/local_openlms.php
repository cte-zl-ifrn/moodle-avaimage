<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Open LMS local extras plugin.
 *
 * @package    local_openlms
 * @copyright  2022 Open LMS (https://www.openlms.net/)
 * @author     Petr Skoda
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['extramenu'] = 'Ekstra eylemler';
$string['notification'] = 'Bildirim';
$string['notification_body'] = 'İleti';
$string['notification_create'] = 'Bildirim ekle';
$string['notification_custom'] = 'Özelleştirildi';
$string['notification_delete'] = 'Bildirimi sil';
$string['notification_delete_confirm'] = 'Bildirim örneği silinip ardından tekrar eklendiyse kullanıcılar tekrar tekrar bildirim alabilir.';
$string['notification_enabled'] = 'Etkin';
$string['notification_extramenu'] = 'Bildirim eylemleri';
$string['notification_import'] = 'Bildirimleri içe aktar';
$string['notification_import_from'] = 'Şuradan al:';
$string['notification_instance'] = 'Şunun için bildirim:';
$string['notification_subject'] = 'Konu';
$string['notification_type'] = 'Bildirim türü';
$string['notification_types'] = 'Bildirim türleri';
$string['notification_update'] = 'Bildirimi güncelleştir';
$string['notification_view'] = 'Bildirim ayrıntıları';
$string['notifications'] = 'Bildirimler';
$string['pluginname'] = 'Open LMS yardımcıları';
$string['privacy:metadata:userid'] = 'Kullanıcı';
$string['privacy:metadata:local_openlms_user_notified:tableexplanation'] = 'Kullanıcı bildirim takibi';
$string['toomanyrecords'] = 'Çok fazla kayıt bulundu';
