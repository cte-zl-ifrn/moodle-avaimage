<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Open LMS local extras plugin.
 *
 * @package    local_openlms
 * @copyright  2022 Open LMS (https://www.openlms.net/)
 * @author     Petr Skoda
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['extramenu'] = 'Lisätoiminnot';
$string['notification'] = 'Ilmoitus';
$string['notification_body'] = 'Viesti';
$string['notification_create'] = 'Lisää ilmoitus';
$string['notification_custom'] = 'Mukautettu';
$string['notification_delete'] = 'Poista ilmoitus';
$string['notification_delete_confirm'] = 'Jos ilmoituksen ilmentymä poistetaan ja lisätään uudelleen myöhemmin, käyttäjille saatetaan ilmoittaa toistuvasti.';
$string['notification_enabled'] = 'Käytössä';
$string['notification_extramenu'] = 'Ilmoitustoiminnot';
$string['notification_import'] = 'Tuo ilmoitukset';
$string['notification_import_from'] = 'Tuo muodossa';
$string['notification_instance'] = 'Ilmoitus kohteelle';
$string['notification_subject'] = 'Aihe';
$string['notification_type'] = 'Ilmoituksen tyyppi';
$string['notification_types'] = 'Ilmoitusten tyypit';
$string['notification_update'] = 'Päivitä ilmoitus';
$string['notification_view'] = 'Ilmoituksen tiedot';
$string['notifications'] = 'Ilmoitukset';
$string['pluginname'] = 'Open LMS -apuohjelmat';
$string['privacy:metadata:userid'] = 'Käyttäjä';
$string['privacy:metadata:local_openlms_user_notified:tableexplanation'] = 'Käyttäjäilmoitusten seuranta';
$string['toomanyrecords'] = 'Löytyi liian monta tietuetta';
