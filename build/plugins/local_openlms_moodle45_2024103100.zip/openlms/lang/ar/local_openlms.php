<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Open LMS local extras plugin.
 *
 * @package    local_openlms
 * @copyright  2022 Open LMS (https://www.openlms.net/)
 * @author     Petr Skoda
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['extramenu'] = 'الإجراءات الإضافية';
$string['notification'] = 'الإعلام';
$string['notification_body'] = 'الرسالة';
$string['notification_create'] = 'إضافة إعلام';
$string['notification_custom'] = 'تم التخصيص';
$string['notification_delete'] = 'حذف الإعلام';
$string['notification_delete_confirm'] = 'في حال حذف مثيل الإعلام ثم إضافته مرة أخرى لاحقًا، قد يتم إعلام المستخدمين بشكل متكرر.';
$string['notification_enabled'] = 'مُمكَّن';
$string['notification_extramenu'] = 'إجراءات الإعلام';
$string['notification_import'] = 'استيراد الإعلامات';
$string['notification_import_from'] = 'الاستيراد من';
$string['notification_instance'] = 'إعلام لـ';
$string['notification_subject'] = 'الموضوع';
$string['notification_type'] = 'نوع الإعلام';
$string['notification_types'] = 'أنواع الإعلامات';
$string['notification_update'] = 'تحديث الإعلام';
$string['notification_view'] = 'تفاصيل الإعلام';
$string['notifications'] = 'الإعلامات';
$string['pluginname'] = 'أدوات Open LMS';
$string['privacy:metadata:userid'] = 'المستخدم';
$string['privacy:metadata:local_openlms_user_notified:tableexplanation'] = 'تتبع إعلامات المستخدم';
$string['toomanyrecords'] = 'تم العثور على عدد كبير جدًا من السجلات';
