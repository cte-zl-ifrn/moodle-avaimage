<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Open LMS local extras plugin.
 *
 * @package    local_openlms
 * @copyright  2022 Open LMS (https://www.openlms.net/)
 * @author     Petr Skoda
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['extramenu'] = 'การดำเนินเพิ่มเติม';
$string['notification'] = 'การแจ้งเตือน';
$string['notification_body'] = 'ข้อความ';
$string['notification_create'] = 'เพิ่มการแจ้งเตือน';
$string['notification_custom'] = 'ปรับแต่งแล้ว';
$string['notification_delete'] = 'ลบการแจ้งเตือน';
$string['notification_delete_confirm'] = 'หากมีการลบอิสแตนซ์ของการแจ้งเตือนและเพิ่มใหม่ในภายหลัง ผู้ใช้จะได้รับการแจ้งเตือนซ้ำ';
$string['notification_enabled'] = 'เปิดใช้งานแล้ว';
$string['notification_extramenu'] = 'การดำเนินการของการแจ้งเตือน';
$string['notification_import'] = 'นำเข้าการแจ้งเตือน';
$string['notification_import_from'] = 'นำเข้าจาก';
$string['notification_instance'] = 'การแจ้งเตือนสำหรับ';
$string['notification_subject'] = 'เรื่อง';
$string['notification_type'] = 'ประเภทการแจ้งเตือน';
$string['notification_types'] = 'ประเภทการแจ้งเตือน';
$string['notification_update'] = 'อัปเดตการแจ้งเตือน';
$string['notification_view'] = 'รายละเอียดการแจ้งเตือน';
$string['notifications'] = 'การแจ้งเตือน';
$string['pluginname'] = 'ยูทิลิตี้ Open LMS';
$string['privacy:metadata:userid'] = 'ผู้ใช้งาน';
$string['privacy:metadata:local_openlms_user_notified:tableexplanation'] = 'การติดตามการแจ้งเตือนของผู้ใช้งาน';
$string['toomanyrecords'] = 'พบบันทึกจำนวนมากเกินไป';
