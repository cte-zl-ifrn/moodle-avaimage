Dynamic menu user profile field for moodle
Now you can create user menu fields that accept a sql query as data definition.