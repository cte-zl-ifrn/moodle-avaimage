<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Log entries for mod_journal
 *
 * @package     mod_journal
 * @copyright   1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 **/
defined('MOODLE_INTERNAL') || die();

$logs = [
    ['module' => 'journal', 'action' => 'view', 'mtable' => 'journal', 'field' => 'name'],
    ['module' => 'journal', 'action' => 'view all', 'mtable' => 'journal', 'field' => 'name'],
    ['module' => 'journal', 'action' => 'view responses', 'mtable' => 'journal', 'field' => 'name'],
    ['module' => 'journal', 'action' => 'add entry', 'mtable' => 'journal', 'field' => 'name'],
    ['module' => 'journal', 'action' => 'update entry', 'mtable' => 'journal', 'field' => 'name'],
    ['module' => 'journal', 'action' => 'update feedback', 'mtable' => 'journal', 'field' => 'name'],
];
