<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Plugin strings are defined here.
 *
 * @package     tiny_fontsize
 * @category    string
 * @copyright   2025 Mikko Haiku <mikko.haiku@iki.fi>
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['button_fontsize'] = 'Font size';
$string['fontsize:use'] = "Allow the plugin usage";
$string['fontsizes'] = "Font sizes";
$string['fontsizes_desc'] = "List of available font sizes separated by a new line.";
$string['fontsizeunit'] = "Font size unit";
$string['fontsizeunit_desc'] = "The CSS unit applied to each font size.";
$string['last_validated'] = 'Last Validated';
$string['license_expires'] = 'Expires';
$string['license_key'] = 'License Key';
$string['license_key_desc'] = 'Enter the license key for this plugin.';
$string['license_purchase_info'] = 'Without a valid license, this plugin\'s settings are locked to their defaults. Purchasing a license from the <a href="{$a}" target="_blank" rel="noopener noreferrer">Moodle Marketplace</a> unlocks the ability to change the configuration and includes support.';
$string['license_status'] = 'Status';
$string['license_valid'] = 'Valid';
$string['license_validation_info'] = 'License Validation Status';
$string['licensingheading'] = 'Licensing';
$string['menuitem_fontsize'] = 'Font size';
$string['pluginname'] = 'Font size plugin';
$string['privacy:metadata'] = 'Font size plugin does not store any personal data';
$string['settings'] = 'Font size settings';
$string['task_validate_license'] = 'Validate license for Font size';
$string['unit_em'] = 'Em (em)';
$string['unit_percent'] = 'Percent (%)';
$string['unit_pt'] = 'Points (pt)';
$string['unit_px'] = 'Pixels (px)';
$string['unit_rem'] = 'Root em (rem)';
$string['validation_error'] = 'Validation Error';
